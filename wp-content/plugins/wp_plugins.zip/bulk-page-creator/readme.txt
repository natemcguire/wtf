=== Plugin Name ===
Contributors: DaganLev
Tags: Solid Code, Dagan Lev, Bulk Page Creator, batch action, add pages, add posts
Requires at least: 3.1
Tested up to: 3.1
Stable tag: trunk

Allows you to create multiple pages in a batch/bulk manner saving time when initially setting up your WordPress site

== Description ==

Allows you to create multiple pages in a batch/bulk manner saving time when initially setting up your WordPress site,
This plugin will give you a startup screen in which you can add as many pages in a quick manner and then by clicking one button will create all the pages


For backwards compatibility, if this section is missing, the full length of the short description will be used, and
Markdown parsed.

== Installation ==

To install this plugin please use the "install" feature from the WordPress site.

== Changelog ==

= 1.0.0 =
* Initial setup

= 1.0.1 =
Fixed issue with extra spaces at end of page titles

= 1.0.3 =
Added a trigger when pressing enter on the page name to add it automatically to the list

= 1.0.4 =
Added a "draft" option to publish pages in draft status

== Screenshots ==

1. View of bulk page creator screen
